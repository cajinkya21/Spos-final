#include <stdio.h>
#include <stdlib.h>
void input();
int display(int ,int [10]);
void firstfit(int ,int [10],int [10],int);
void nextfit(int ,int [10],int [10],int);
void bestfit(int ,int [10],int [10],int);
void worstfit(int,int [10],int [10],int);
void asort(int [10], int);
void dsort(int [10], int);
int main() {
	int npr,nh=0,i,j,k,pr[10],hol[10],ch,temp[10],choice,l;
	while(1) {
		printf("\n\n\t\t-------Choose Your Option:---------\n\n");
		printf("\n\t\t1.INPUT\n");
		printf("\n\t\t2.FIRST FIT\n");
		printf("\n\t\t3.BEST FIT\n");
		printf("\n\t\t4.WORST FIT\n"); 
		printf("\n\t\t5.NEXT FIT\n"); 
		printf("\n\t\t6.EXIT\n");
		printf("\n\t\tEnter Your Choice:\n\t\t");
		scanf("%d",&choice);
		for(i=0;i<nh;i++) {            
                      	temp[i]=hol[i];
                }
		switch(choice) {
			case 1:
				printf("\n Enter the number of processes:");
                		scanf("%d",&npr);
                		printf("\nNumber of holes:");
                		scanf("%d",&nh);
                		for(i=0;i<npr;i++) {
                     			printf("\nProcess %d:",i+1);  
                     			scanf("%d",&pr[i]);  
                  		}
                		for(i=0;i<nh;i++) {
                     			printf("\nHole %d:",i+1);  
                     			scanf("%d",&hol[i]);  
                      			temp[i]=hol[i];
                  		}
				break;
			case 2:
				firstfit(npr,temp,pr,nh);
				break;
				
			case 3:		
				bestfit(npr,temp,pr,nh);	
				break;
			case 4:
				worstfit(npr,temp,pr,nh);
				break;
			case 5:
				nextfit(npr,temp,pr,nh);
				break;
			case 6:
				printf("\n\nThank you.......... \n\n");
				exit(0);
				break;
			default:
				printf("\nYou enterd invalid choice,Plz enter valid choice\n");
				break;
		}		
	}
	return 0;
}
void firstfit(int npr,int hol[10],int pr[10],int nh){
   	int i,j,k,flag=0,num,l,ff[10],frag[10],itot = 0;
	int temp[10],ext,sum,inter[10],s=0,fff[10],cc=0,sub=0;
	printf("\nPROCESS\t\tPROCESS SIZE\tBLOCK SIZE\tINTERNAL FRAG.\tExternal FRAG\n");
	for(i =0  ; i<nh ;i++)
			fff[i]=hol[i];
   	for(i=0;i<npr;i++){
		flag=0;
      		for(j=0;j<nh;j++){
	     		temp[j] = hol[j];
	                if(pr[i]<hol[j]){
				inter[i] = pr[i];
				ff[j] = hol[j];
			        hol[j]=hol[j]-pr[i];
				frag[j] = hol[j];
                		flag=1;	
				break;             
              		}
            		else if(pr[i]==hol[j]) {
				cc++;
				inter[i] =pr[i];
				fff[j] = hol[j];
		 		ff[j] = hol[j];
                 		flag=1;
	          		frag[j] = hol[j]-pr[i];
		                for(k=j;k<nh-1;k++) {
                   			hol[k]=hol[k+1];
                 		}  
		 		nh--;
                 		break;
            		} 
       		}
       		if(flag==0) {
	   		printf("\n Hole is not Available…..");
			ff[j] = 0;
			frag[j] = 0;
			ext = 0;
			goto label;
    	   		//break;
       		}
	 	ext = display(nh,hol);
		label: printf("\n%d\t\t%d\t\t%d\t\t%d\t\t\t%d\n",i+1,pr[i],ff[j],frag[j],ext);
		itot = itot + frag[j];
   }
	for(i = 0; i< npr ;i++){
		s += inter[i];
		
	}
	for(j = 0;j < nh ; j++) {
		if(fff[j] != hol[j])
			sub +=hol[j];
	}
 	printf("\nTotal Internal Fragmentation:%d",sub);
	sum = display(nh,hol);
	printf("\nTotal External Fragmentation:%d",sum);	
}    
void bestfit(int npr,int hol[10],int pr[10],int nh){
	int i,j,k,flag=0,num,l,ff[10],frag[10];
	int itot = 0,temp[10],ext,sum,inter[10],s=0,fff[10],cc=0,sub=0;
	printf("\nPROCESS\t\tPROCESS SIZE\tBLOCK SIZE\tINTERNAL FRAG.\tExternal FRAG\n");
	asort(hol, nh);
	for(i = 0; i < nh ; i++)
		fff[i]=hol[i];
   	for(i=0;i<npr;i++){
      		flag=0;
      		for(j=0;j<nh;j++){
	     		temp[j] = hol[j];
			if(pr[i]<hol[j]){
				inter[i] = pr[i];
				ff[j] = hol[j];
			        hol[j]=hol[j]-pr[i];
				frag[j] = hol[j];
		                flag=1;	
				break;             
              		}
            		else if(pr[i]==hol[j]) {
				cc++;
				inter[i] =pr[i];
				fff[j] = hol[j];
				ff[j] = hol[j];
                 		flag=1;
		 		frag[j] = hol[j]-pr[i];
               			for(k=j;k<nh-1;k++) {
                   			hol[k]=hol[k+1];
                 		}  
		 		nh--;
                 		break;
            		} 
       		}
       		if(flag==0) {
	   		printf("\n Hole is not Available…..");
			ff[j] = 0;
			frag[j] = 0;
			ext = 0;
    	//   		break;
       		}
	 	ext = display(nh,hol);
		printf("\n%d\t\t%d\t\t%d\t\t%d\t\t\t%d\n",i+1,pr[i],ff[j],frag[j],ext);
		itot = itot + frag[j];
   	}
	for(i = 0; i< npr ;i++){
		s +=inter[i];	
	}
	for(j = 0;j < nh ; j++) {
		if(fff[j] != hol[j])
			sub +=hol[j];
	}
 	printf("\nTotal Internal Fragmentation:%d",sub);
	sum = display(nh,hol);
	printf("\nTotal External Fragmentation:%d",sum);	
}    
void worstfit(int npr,int hol[10],int pr[10],int nh) {
	int i,j,k,max,flag,wf[10],frag[10],itot=0,ext,sum,fff[10],sub = 0;
	printf("\nPROCESS\t\tPROCESS SIZE\tBLOCK SIZE\tINTERNAL FRAG\tExternal FRAG\n");
	dsort(hol, nh);
	for(j=0 ; j<nh ; j++)
			fff[j] = hol[j];
	for(i=0;i<npr;i++){
     		flag=0;
       		for(j=0;j<nh;j++) {
            		if(pr[i]<=hol[j]) {
				wf[j] = hol[j];
				frag[j] = hol[j]-pr[i];
                          	flag=1;  
				max=j;
                 		for(k=j;k<nh;k++) {
                   			if((hol[max]<hol[k])&&(pr[i]<=hol[k]))
						max=k;
                 		}
              			if(pr[i]<hol[max]) {
					wf[j] = hol[max];
					frag[j] = hol[max]-pr[i];
              				hol[max]=hol[max]-pr[i];
               				break;             
               			}
              			else if(pr[i]==hol[max]) {
               				wf[j] = hol[max];
					frag[j] = hol[max]-pr[i];
                			for(k=max;k<nh-1;k++)
                   				hol[k]=hol[k+1];
                				nh--;
                 				break;
              				}         
            			}
          	} 
    		if(flag==0) {
			printf("\n Hole is not Available…..");
			wf[j] = 0;
			frag[j] = 0;
			ext = 0;
    			//break;
		}
		ext =  display(nh,hol); 
		printf("\n%d\t\t%d\t\t%d\t\t%d\t\t\t%d\n",i+1,pr[i],wf[j],frag[j],ext);
		itot = itot + frag[j];
      	}
	for(j=0 ; j<nh ; j++){
		if(fff[j] != hol[j])
			sub += hol[j];
	}
	printf("\nTotal Internal Fragmentation:%d",sub);	
	sum=display(nh,hol);
	printf("\nTotal External Fragmentation:%d",sum);	
}

//Next Fit
void nextfit(int npr,int hol[10],int pr[10],int nh){
	int i,j=0,k,flag=0,nf[10],frag[10],itot=0,ext,sum,fff[10],sub = 0;
 	printf("\nPROCESS\t\tPROCESS SIZE\tBLOCK SIZE\tINTERNAL FRAG\tExternal FRAG\n");
	for(k=0 ;k<nh ; k++){
		fff[k] = hol[k];
	}	
	for(i=0;i<npr;i++){
     		flag=0;
       		for(;j<nh;) {
               		if(pr[i]<hol[j]){
				nf[j]=hol[j];
				frag[j] = hol[j]-pr[i];
                		hol[j]=hol[j]-pr[i];
				flag=1;
               			break;             
              		 }
              		else if(pr[i]==hol[j]) {
				nf[j]=hol[j];
				frag[j] = hol[j]-pr[i];
            			flag=1;
               			for(k=j;k<nh-1;k++)
                   			hol[k]=hol[k+1];
                		nh--;
   				break;
              		}         
                	j=(j+1)%nh;
			if(j == 0)
				break;
          	} 
    		if(flag==0) {
			printf("\n Hole is not Available…..");
			nf[j] = 0;
			frag[j] = 0;
			ext = 0;
    			//break;
		}
    		ext=display(nh,hol);  
		printf("\n%d\t\t%d\t\t%d\t\t%d\t\t\t%d\n",i+1,pr[i],nf[j],frag[j],ext);
		itot = itot + frag[j];
      	}
	for(k=0 ; k<nh ;k++){
		if(fff[k] != hol[k])
			sub += hol[k];
	}
	printf("\nTotal Internal Fragmentation:%d",sub);	
	sum=display(nh,hol);
	printf("\nTotal External Fragmentation:%d",sum);	
 } 
int display(int nh,int hol[10]){
	int sum = 0,i;
	for(i=0;i<nh;i++) {
  		sum = sum + hol[i];
	}
	return sum;
}
void asort(int hol[10], int nh){
	int swap, i, j;
	for(i = 0; i < nh - 1; i++){
		for(j = 0; j < nh - 1; j++){
			if(hol[j] > hol[j + 1]){
				swap= hol[j];
				hol[j] = hol[j + 1];
				hol[j + 1] = swap;
			}
		}
	}
}
void dsort(int hol[10], int nh){
	int swap, i, j;
	for(i = 0; i < nh - 1; i++){
		for(j = 0; j < nh - 1; j++){
			if(hol[j] < hol[j + 1]){
				swap= hol[j];
				hol[j] = hol[j + 1];
				hol[j + 1] = swap;
			}
		}
	}
}  
	
